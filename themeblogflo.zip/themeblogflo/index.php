<!-- ~~~~~~~~~~~~~~~ SECTION ~~~~~~~~~~~~~~~ -->

<section class="maincontainer">
<div class="containerarticles">

  <article class="mainarticle">

  </article>

  <div class="colonnesarticles">

    <div class="colonne1">
      <article class="articlesimple articlecolor1">
        <figure class="figurearticle">
          <p id="textoverimg1"></p>
          <img src="img/article1" id="imgarticle1" alt="de la grosse tech">
        </figure>

        <h5>Twitter tweaks its design</h5>
        <div class="divsoustitrearticle">
          <img src="img/horloge" alt="horloge">
          <p class="soustitrearticle">Monday, 06 October</p>
        </div>
        <p class="descriptionarticle">Twitter tweaks its design again in an attempt to woo newcomers</p>
      </article>

      <article class="articlesimple articlecolor2">
        <figure class="figurearticle">
          <img src="img/article2" alt="">
        </figure>
        <h5>the new Surface Pro</h5>
        <div class="divsoustitrearticle">
          <img src="img/horloge" alt="horloge">
          <p class="soustitrearticle">Tuesday, 19 July</p>
        </div>
        <p class="descriptionarticle">The Surface Laptop makes the new Surface Pro mostly a nonstarter</p>
      </article>
    </div>

    <div class="colonne2">
      <article class="articlesimple articlecolor3">
        <figure class="figurearticle">
          <img src="img/article3" alt="">
        </figure>
        <h5>Columbus meetup is happening</h5>
        <div class="divsoustitrearticle">
          <img src="img/horloge" alt="horloge">
          <p class="soustitrearticle">Friday, 03 February</p>
        </div>
        <p class="descriptionarticle">The Columbus meetup is happening tonight but the location changed</p>
      </article>

      <article class="articlesimple articlecolor4">
        <figure class="figurearticle">
          <img src="img/article4" alt="">
        </figure>
        <h5>Highspot raises $15 million</h5>
        <div class="divsoustitrearticle">
          <img src="img/horloge" alt="horloge">
          <p class="soustitrearticle">Sunday, 11 November</p>
        </div>
        <p class="descriptionarticle">Highspot raises $15 million to perfect your sales pitch</p>
      </article>

    </div>

    <div class="colonne3">
      <article class="articlesimple articlecolor5">
        <figure class="figurearticle">
          <img src="img/article5" alt="">
        </figure>
        <h5>Ridibooks scores $20M</h5>
        <div class="divsoustitrearticle">
          <img src="img/horloge" alt="horloge">
          <p class="soustitrearticle">Sunday, 18 November</p>
        </div>
        <p class="descriptionarticle">Korean e-book service Ridibooks scores $20M Series C</p>
      </article>

      <article class="articlesimple articlecolor6">
        <figure class="figurearticle">
          <img src="img/article6" alt="">
        </figure>
        <h5>Uber rival Careem closes $500M raise</h5>
        <div class="divsoustitrearticle">
          <img src="img/horloge" alt="horloge">
          <p class="soustitrearticle">Monday, 23 March</p>
        </div>
        <p class="descriptionarticle">Uber rival Careem closes $500M raise at $1B+ valuation as Daimler steps in</p>
      </article>

    </div>
  </div>
</div>
</section>
<!-- ~~~~~~~~~~~~~~~END SECTION ~~~~~~~~~~~~~~~ -->


<!-- ~~~~~~~~~~~~~~~ TABLE ~~~~~~~~~~~~~~~ -->
<section class="containertableau">
<h3 class="titretable">JOLI TABLEAU</h3>

<div class="containeronglets">
  <div class="onglet1">
    <p>onglet 1</p>
  </div>

  <div class="onglet2">
    <p>onglet 2</p>
  </div>

  <div class="onglet3">
    <p>onglet 3</p>
  </div>
</div>

<div class="page1">
  <p>Présentation

Terminons ce chapitre avec une dernière fonction, dont le but est de récupérer tous les éléments HTML d'une classe donnée.
Comme il n'en existe pas, nous allons la créer.

Notre fonction possèdera un argument obligatoire : le nom de la classe.
L'argument suivant, facultatif, sera l'élément "racine" pour la rechercher : s'il n'est pas précisé, on recherche dans tout le document. Sinon, on cherche uniquement parmi les "fils" de cet élément.

Nous utiliserons également une regex pour savoir si la fonction possède la classe recherchée, afin de la rendre compatible avec les multi-classes.</p>
</div>

<div class="page2">
  <p>Récupérer les classes dans un tableau

Si on affiche en JS l'attribut className d'un objet, on récupère toutes les classes dans une seule chaîne de caractères.

Dans l'exemple précédent, ça nous donne :

Citation : div.className

  titre encadre important

Pas très pratique.

Qu'à cela ne tienne, si on veut récupérer les noms de classes dans un tableau JS, il nous suffit d'utiliser la méthode split de l'objet String, pour découper notre chaîne de caractères aux endroits où se trouvent des espaces.</p>
</div>

<div class="page3">
  <p>Un grand classique du JS est d'afficher ou de masquer à volonté les éléments de la page.

Derrière ce tour de passe-passe se cachent simplement les propriétés CSS display et visibility, qu'on modifie à n'importe quel moment en utilisant l'objet style comme vous avez appris à le faire.

Nous allons dans cette partie créer deux fonctions :

  toggleVisibility(elmt) : pour rendre l'élément visible ou invisible ;

  toggleDisplay(elmt) : pour afficher ou masquer l'élément.

Quelques remarques
visibility et display

Rappelons en images la différence entre les deux propriétés CSS suivantes :</p>
</div>
</section>

<!-- ~~~~~~~~~~~~~~~END TABLE ~~~~~~~~~~~~~~~ -->
