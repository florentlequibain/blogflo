<!-- ~~~~~~~~~~~~~~~ FOOTER ~~~~~~~~~~~~~~~ -->
<footer>

<div class="containerform">
  <h5>Suscribe!</h5>

  <form>
    <div class="form-group row">
      <label for="inputEmail3" class="col-3 col-sm-2 form-control-label formtext">Email</label>
      <div class="col-9 col-sm-10">
        <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
      </div>
    </div>

    <div class="form-group row">
      <label for="inputName3 formtext" class="col-3 col-sm-2 form-control-label formtext">Name</label>
      <div class="col-9 col-sm-10">
        <input type="Name" class="form-control" id="inputName3" placeholder="Name">
      </div>
    </div>

    <div class="form-group row">
      <label for="inputSurname3 formtext" class="col-3 col-sm-2 form-control-label formtext">Surname</label>
      <div class="col-9 col-sm-10">
        <input type="Surname" class="form-control" id="inputSurname3" placeholder="Surname">
      </div>
    </div>

    <div class="form-group row">
      <label for="inputPhone3 formtext" class="col-3 col-sm-2 form-control-label formtext">Phone</label>
      <div class="col-9 col-sm-10">
        <input type="Phone" class="form-control" id="inputPhone3" placeholder="Phone">
      </div>
    </div>

   <button type="button" class="offset-2 col-8 btn btn-secondary" onclick="alert('Bravo!!');" onclick="this.textContent='Envoyé';">Send</button>

  </form>
</div>

  <script type="text/javascript">

function affichage()
{
temps= new Date();
afficher = showFilled(temps.getHours())+ ":" + showFilled(temps.getMinutes()) + ":" + showFilled(temps.getSeconds());
document.all.heure.innerHTML = afficher;

setTimeout("affichage()",1000);
}
function showFilled(Value)
{
return (Value > 9) ? "" + Value : "0" + Value;
}


</script>

<body onload="affichage()">
 <p class="dateetheure">Nous sommes le <script type="text/javascript">
         d = new Date();
       document.write();
       document.write(d.toLocaleDateString());
       document.write();
     </script> et il est <span id="heure"></span>
</p>

<div class="timer">
 <span>You spend a lot of time here! :</span>
 <label id="minutes">00</label>:<label id="seconds">00</label>

   <script type="text/javascript">
       var minutesLabel = document.getElementById("minutes");
       var secondsLabel = document.getElementById("seconds");
       var totalSeconds = 0;
       setInterval(setTime, 1000);

       function setTime()
       {
           ++totalSeconds;
           secondsLabel.innerHTML = pad(totalSeconds%60);
           minutesLabel.innerHTML = pad(parseInt(totalSeconds/60));
       }

       function pad(val)
       {
           var valString = val + "";
           if(valString.length < 2)
           {
               return "0" + valString;
           }
           else
           {
               return valString;
           }
       }
   </script>
</div>

<div id="chrono" class="col-xs-12 col-sm-12 col-md-12  col-lg-10 mt-1 mb-3 mx-auto"></div>

</footer>
<!-- ~~~~~~~~~~~~~~~ END FOOTER ~~~~~~~~~~~~~~~ -->
