
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> <html xmlns="http://www.w3.org/1999/xhtml"> <head profile="http://gmpg.org/xfn/11">   <title><?php bloginfo('name') ?><?php if ( is_404() ) : ?> &raquo; <?php _e('Not Found') ?><?php elseif ( is_home() ) : ?> &raquo; <?php bloginfo('description') ?><?php else : ?><?php wp_title() ?><?php endif ?></title>   <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" /> <meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats --> <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" /> <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" /> <link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" /> <link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" /> <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" /><?php wp_head(); ?>   <?php wp_get_archives('type=monthly&format=link'); ?> <?php //comments_popup_script(); <?php wp_head(); ?>   </head> <body>

  <!-- ~~~~~~~~~~~~~~~ HEADER ~~~~~~~~~~~~~~~ -->

<header>
<div class="title">
  <div class="titleandimg">
    <figure>
      <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/lego.png" id="title" alt="lego">
    </figure>
    <h1 id="title">FUTURE!</h1>
  </div>
  <p class="soustitre">An other way to see tech</p>
</div>
</header>

<script>
// var montitre = document.getElementById('title');
// alert(montitre);
//
var articles = document.getElementsByTagName('article');

for (var i = 0, c = articles.length ; i < c ; i++) {
alert('Element n° ' + (i + 1) + ' : ' + articles[i]);
}
</script>
<!-- ~~~~~~~~~~~~~~~ END HEADER ~~~~~~~~~~~~~~~ -->


<!-- ~~~~~~~~~~~~~~~ SECTION ~~~~~~~~~~~~~~~ -->

<section class="maincontainer">
<div class="containerarticles">

<article class="mainarticle">

</article>

<div class="colonnesarticles">

  <div class="colonne1">
    <article class="articlesimple articlecolor1">
      <figure class="figurearticle">
        <p id="textoverimg1"></p>
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/article1" id="imgarticle1" alt="de la grosse tech">
      </figure>

      <h5>Twitter tweaks its design</h5>
      <div class="divsoustitrearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/horloge" alt="horloge">
        <p class="soustitrearticle">Monday, 06 October</p>
      </div>
      <p class="descriptionarticle">Twitter tweaks its design again in an attempt to woo newcomers</p>
    </article>

    <article class="articlesimple articlecolor2">
      <figure class="figurearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/article2" id="imgarticle1" alt="de la grosse tech">
      </figure>
      <h5>the new Surface Pro</h5>
      <div class="divsoustitrearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/horloge" alt="horloge">
        <p class="soustitrearticle">Tuesday, 19 July</p>
      </div>
      <p class="descriptionarticle">The Surface Laptop makes the new Surface Pro mostly a nonstarter</p>
    </article>
  </div>

  <div class="colonne2">
    <article class="articlesimple articlecolor3">
      <figure class="figurearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/article3" id="imgarticle1" alt="de la grosse tech">
      </figure>
      <h5>Columbus meetup is happening</h5>
      <div class="divsoustitrearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/horloge" alt="horloge">
        <p class="soustitrearticle">Friday, 03 February</p>
      </div>
      <p class="descriptionarticle">The Columbus meetup is happening tonight but the location changed</p>
    </article>

    <article class="articlesimple articlecolor4">
      <figure class="figurearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/article4" id="imgarticle1" alt="de la grosse tech">
      </figure>
      <h5>Highspot raises $15 million</h5>
      <div class="divsoustitrearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/horloge" alt="horloge">
        <p class="soustitrearticle">Sunday, 11 November</p>
      </div>
      <p class="descriptionarticle">Highspot raises $15 million to perfect your sales pitch</p>
    </article>

  </div>

  <div class="colonne3">
    <article class="articlesimple articlecolor5">
      <figure class="figurearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/article5" id="imgarticle1" alt="de la grosse tech">
      </figure>
      <h5>Ridibooks scores $20M</h5>
      <div class="divsoustitrearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/horloge" alt="horloge">
        <p class="soustitrearticle">Sunday, 18 November</p>
      </div>
      <p class="descriptionarticle">Korean e-book service Ridibooks scores $20M Series C</p>
    </article>

    <article class="articlesimple articlecolor6">
      <figure class="figurearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/article6" id="imgarticle1" alt="de la grosse tech">
      </figure>
      <h5>Uber rival Careem closes $500M raise</h5>
      <div class="divsoustitrearticle">
        <img src="<?php echo esc_url (get_template_directory_uri() );?>/img/horloge" alt="horloge">
        <p class="soustitrearticle">Monday, 23 March</p>
      </div>
      <p class="descriptionarticle">Uber rival Careem closes $500M raise at $1B+ valuation as Daimler steps in</p>
    </article>

  </div>
</div>
</div>
</section>
<!-- ~~~~~~~~~~~~~~~END SECTION ~~~~~~~~~~~~~~~ -->


<!-- ~~~~~~~~~~~~~~~ TABLE ~~~~~~~~~~~~~~~ -->
<section class="containertableau">
<h3 class="titretable">JOLI TABLEAU</h3>

<div class="containeronglets">
<div class="onglet1">
  <p>onglet 1</p>
</div>

<div class="onglet2">
  <p>onglet 2</p>
</div>

<div class="onglet3">
  <p>onglet 3</p>
</div>
</div>

<div class="page1">
<p>Présentation

Terminons ce chapitre avec une dernière fonction, dont le but est de récupérer tous les éléments HTML d'une classe donnée.
Comme il n'en existe pas, nous allons la créer.

Notre fonction possèdera un argument obligatoire : le nom de la classe.
L'argument suivant, facultatif, sera l'élément "racine" pour la rechercher : s'il n'est pas précisé, on recherche dans tout le document. Sinon, on cherche uniquement parmi les "fils" de cet élément.

Nous utiliserons également une regex pour savoir si la fonction possède la classe recherchée, afin de la rendre compatible avec les multi-classes.</p>
</div>

<div class="page2">
<p>Récupérer les classes dans un tableau

Si on affiche en JS l'attribut className d'un objet, on récupère toutes les classes dans une seule chaîne de caractères.

Dans l'exemple précédent, ça nous donne :

Citation : div.className

titre encadre important

Pas très pratique.

Qu'à cela ne tienne, si on veut récupérer les noms de classes dans un tableau JS, il nous suffit d'utiliser la méthode split de l'objet String, pour découper notre chaîne de caractères aux endroits où se trouvent des espaces.</p>
</div>

<div class="page3">
<p>Un grand classique du JS est d'afficher ou de masquer à volonté les éléments de la page.

Derrière ce tour de passe-passe se cachent simplement les propriétés CSS display et visibility, qu'on modifie à n'importe quel moment en utilisant l'objet style comme vous avez appris à le faire.

Nous allons dans cette partie créer deux fonctions :

toggleVisibility(elmt) : pour rendre l'élément visible ou invisible ;

toggleDisplay(elmt) : pour afficher ou masquer l'élément.

Quelques remarques
visibility et display

Rappelons en images la différence entre les deux propriétés CSS suivantes :</p>
</div>
</section>

<!-- ~~~~~~~~~~~~~~~END TABLE ~~~~~~~~~~~~~~~ -->





<!-- ~~~~~~~~~~~~~~~ FOOTER ~~~~~~~~~~~~~~~ -->
<footer>

<div class="containerform">
<h5>Suscribe!</h5>

<form>
 <div class="form-group row">
   <label for="inputEmail3" class="col-3 col-sm-2 form-control-label formtext">Email</label>
   <div class="col-9 col-sm-10">
     <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
   </div>
 </div>

 <div class="form-group row">
   <label for="inputName3 formtext" class="col-3 col-sm-2 form-control-label formtext">Name</label>
   <div class="col-9 col-sm-10">
     <input type="Name" class="form-control" id="inputName3" placeholder="Name">
   </div>
 </div>

 <div class="form-group row">
   <label for="inputSurname3 formtext" class="col-3 col-sm-2 form-control-label formtext">Surname</label>
   <div class="col-9 col-sm-10">
     <input type="Surname" class="form-control" id="inputSurname3" placeholder="Surname">
   </div>
 </div>

 <div class="form-group row">
   <label for="inputPhone3 formtext" class="col-3 col-sm-2 form-control-label formtext">Phone</label>
   <div class="col-9 col-sm-10">
     <input type="Phone" class="form-control" id="inputPhone3" placeholder="Phone">
   </div>
 </div>

<button type="button" class="offset-2 col-8 btn btn-secondary" onclick="alert('Bravo!!');" onclick="this.textContent='Envoyé';">Send</button>

</form>
</div>

<script type="text/javascript">

function affichage()
{
temps= new Date();
afficher = showFilled(temps.getHours())+ ":" + showFilled(temps.getMinutes()) + ":" + showFilled(temps.getSeconds());
document.all.heure.innerHTML = afficher;

setTimeout("affichage()",1000);
}
function showFilled(Value)
{
return (Value > 9) ? "" + Value : "0" + Value;
}


</script>

<body onload="affichage()">
<p class="dateetheure">Nous sommes le <script type="text/javascript">
      d = new Date();
    document.write();
    document.write(d.toLocaleDateString());
    document.write();
  </script> et il est <span id="heure"></span>
</p>

<div class="timer">
<span>You spend a lot of time here! :</span>
<label id="minutes">00</label>:<label id="seconds">00</label>

<script type="text/javascript">
    var minutesLabel = document.getElementById("minutes");
    var secondsLabel = document.getElementById("seconds");
    var totalSeconds = 0;
    setInterval(setTime, 1000);

    function setTime()
    {
        ++totalSeconds;
        secondsLabel.innerHTML = pad(totalSeconds%60);
        minutesLabel.innerHTML = pad(parseInt(totalSeconds/60));
    }

    function pad(val)
    {
        var valString = val + "";
        if(valString.length < 2)
        {
            return "0" + valString;
        }
        else
        {
            return valString;
        }
    }
</script>
</div>

<div id="chrono" class="col-xs-12 col-sm-12 col-md-12  col-lg-10 mt-1 mb-3 mx-auto"></div>

</footer>
<!-- ~~~~~~~~~~~~~~~ END FOOTER ~~~~~~~~~~~~~~~ -->
<link href="https://fonts.googleapis.com/css?family=Bubbler+One|Montserrat:700" rel="stylesheet">
<link src="<?php echo get_bloginfo('template_directory'); ?>/css/main.css"></link>
<script src="<?php echo get_bloginfo('template_directory'); ?>/js/plugins.js"></script>
<script src="<?php echo get_bloginfo('template_directory'); ?>/js/main.js"></script>
<script src="<?php echo get_bloginfo('template_directory'); ?>/js/jquery-3.2.1.js"></script>
<script src="<?php echo get_bloginfo('template_directory'); ?>/js/tether.min.js"></script>
<script src="<?php echo get_bloginfo('template_directory'); ?>/js/bootstrap.js"></script>
