<!doctype html>
<html class="no-js" lang="fr">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>FUTURE! The blog to be</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://fonts.googleapis.com/css?family=Bubbler+One|Montserrat:700" rel="stylesheet">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/style.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>

      <!-- ~~~~~~~~~~~~~~~ HEADER ~~~~~~~~~~~~~~~ -->

  <header>
    <div class="title">
      <div class="titleandimg">
        <figure>
          <img src="img/lego.png" alt="lego espace">
        </figure>
        <h1 id="title">FUTURE!</h1>
      </div>
      <p class="soustitre">An other way to see tech</p>
    </div>
  </header>

  <script>
    // var montitre = document.getElementById('title');
    // alert(montitre);
    //
    var articles = document.getElementsByTagName('article');

    for (var i = 0, c = articles.length ; i < c ; i++) {
    alert('Element n° ' + (i + 1) + ' : ' + articles[i]);
    }
</script>
  <!-- ~~~~~~~~~~~~~~~ END HEADER ~~~~~~~~~~~~~~~ -->
